
async function loadCourses(){
  const resp = await fetch('data/courses.json');
  const data = await resp.json();
  const container = document.getElementById('courses');
  container.innerHTML = '';
  data.forEach(c=>{
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `<h3>${c.title}</h3><p>${c.short}</p><p><a href="course.html?id=${c.id}">Open course</a></p>`;
    container.appendChild(card);
  });
}
document.getElementById('search').addEventListener('input', async e=>{
  const q = e.target.value.toLowerCase();
  const resp = await fetch('data/courses.json');
  const data = await resp.json();
  const filtered = data.filter(c => c.title.toLowerCase().includes(q) || c.short.toLowerCase().includes(q));
  const container = document.getElementById('courses');
  container.innerHTML = '';
  filtered.forEach(c=>{
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `<h3>${c.title}</h3><p>${c.short}</p><p><a href="course.html?id=${c.id}">Open course</a></p>`;
    container.appendChild(card);
  });
});
// initial load
loadCourses();
